# Sports Website
This is a static HTML,CSS based website created as part of a project in sophomore year of college.
To run this project download all the files in one folder and open them in any browser.
